﻿namespace PTUDWin_Final
{
    partial class frmDangkyhp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ccbCtdt = new System.Windows.Forms.ComboBox();
            this.txTimkiem = new System.Windows.Forms.TextBox();
            this.btnTimkiem = new System.Windows.Forms.Button();
            this.dshpData = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnYeucaumolop = new System.Windows.Forms.Button();
            this.btnDangkyhocct = new System.Windows.Forms.Button();
            this.btnDangkyhoclai = new System.Windows.Forms.Button();
            this.btnDangkyHPmoi = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dshpData)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 19);
            this.label1.TabIndex = 11;
            this.label1.Text = "Chương trình đào tạo";
            // 
            // ccbCtdt
            // 
            this.ccbCtdt.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ccbCtdt.FormattingEnabled = true;
            this.ccbCtdt.Location = new System.Drawing.Point(207, 30);
            this.ccbCtdt.Name = "ccbCtdt";
            this.ccbCtdt.Size = new System.Drawing.Size(192, 27);
            this.ccbCtdt.TabIndex = 12;
            this.ccbCtdt.Text = "Tất cả";
            // 
            // txTimkiem
            // 
            this.txTimkiem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txTimkiem.Location = new System.Drawing.Point(477, 71);
            this.txTimkiem.Name = "txTimkiem";
            this.txTimkiem.Size = new System.Drawing.Size(190, 27);
            this.txTimkiem.TabIndex = 13;
            // 
            // btnTimkiem
            // 
            this.btnTimkiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.btnTimkiem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimkiem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnTimkiem.Location = new System.Drawing.Point(673, 65);
            this.btnTimkiem.Name = "btnTimkiem";
            this.btnTimkiem.Size = new System.Drawing.Size(101, 37);
            this.btnTimkiem.TabIndex = 14;
            this.btnTimkiem.Text = "Tìm kiếm";
            this.btnTimkiem.UseVisualStyleBackColor = false;
            this.btnTimkiem.Click += new System.EventHandler(this.btnTimkiem_Click);
            // 
            // dshpData
            // 
            this.dshpData.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dshpData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dshpData.Location = new System.Drawing.Point(30, 112);
            this.dshpData.MultiSelect = false;
            this.dshpData.Name = "dshpData";
            this.dshpData.ReadOnly = true;
            this.dshpData.RowHeadersWidth = 51;
            this.dshpData.RowTemplate.Height = 24;
            this.dshpData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dshpData.Size = new System.Drawing.Size(759, 356);
            this.dshpData.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(26, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 19);
            this.label2.TabIndex = 16;
            this.label2.Text = "Danh sách học phần đăng ký";
            // 
            // btnYeucaumolop
            // 
            this.btnYeucaumolop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.btnYeucaumolop.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYeucaumolop.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnYeucaumolop.Location = new System.Drawing.Point(30, 474);
            this.btnYeucaumolop.Name = "btnYeucaumolop";
            this.btnYeucaumolop.Size = new System.Drawing.Size(150, 50);
            this.btnYeucaumolop.TabIndex = 17;
            this.btnYeucaumolop.Text = "Yêu cầu mở lớp bổ sung";
            this.btnYeucaumolop.UseVisualStyleBackColor = false;
            this.btnYeucaumolop.Click += new System.EventHandler(this.btnYeucaumolop_Click);
            // 
            // btnDangkyhocct
            // 
            this.btnDangkyhocct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.btnDangkyhocct.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangkyhocct.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDangkyhocct.Location = new System.Drawing.Point(226, 474);
            this.btnDangkyhocct.Name = "btnDangkyhocct";
            this.btnDangkyhocct.Size = new System.Drawing.Size(173, 50);
            this.btnDangkyhocct.TabIndex = 18;
            this.btnDangkyhocct.Text = "Đăng ký học cải thiện";
            this.btnDangkyhocct.UseVisualStyleBackColor = false;
            this.btnDangkyhocct.Click += new System.EventHandler(this.btnDangkyhocct_Click);
            // 
            // btnDangkyhoclai
            // 
            this.btnDangkyhoclai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.btnDangkyhoclai.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangkyhoclai.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDangkyhoclai.Location = new System.Drawing.Point(450, 474);
            this.btnDangkyhoclai.Name = "btnDangkyhoclai";
            this.btnDangkyhoclai.Size = new System.Drawing.Size(150, 50);
            this.btnDangkyhoclai.TabIndex = 19;
            this.btnDangkyhoclai.Text = "Đăng ký học lại";
            this.btnDangkyhoclai.UseVisualStyleBackColor = false;
            this.btnDangkyhoclai.Click += new System.EventHandler(this.btnDangkyhoclai_Click);
            // 
            // btnDangkyHPmoi
            // 
            this.btnDangkyHPmoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.btnDangkyHPmoi.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangkyHPmoi.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDangkyHPmoi.Location = new System.Drawing.Point(641, 474);
            this.btnDangkyHPmoi.Name = "btnDangkyHPmoi";
            this.btnDangkyHPmoi.Size = new System.Drawing.Size(148, 50);
            this.btnDangkyHPmoi.TabIndex = 20;
            this.btnDangkyHPmoi.Text = "Đăng ký học phần mới";
            this.btnDangkyHPmoi.UseVisualStyleBackColor = false;
            this.btnDangkyHPmoi.Click += new System.EventHandler(this.btnDangkyHPmoi_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(329, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 19);
            this.label3.TabIndex = 22;
            this.label3.Text = "Nhập tên học phần";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(429, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Lọc";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmDangkyhp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(824, 536);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnDangkyHPmoi);
            this.Controls.Add(this.btnDangkyhoclai);
            this.Controls.Add(this.btnDangkyhocct);
            this.Controls.Add(this.btnYeucaumolop);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dshpData);
            this.Controls.Add(this.btnTimkiem);
            this.Controls.Add(this.txTimkiem);
            this.Controls.Add(this.ccbCtdt);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmDangkyhp";
            this.Text = "Đăng ký học phần";
            ((System.ComponentModel.ISupportInitialize)(this.dshpData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ccbCtdt;
        private System.Windows.Forms.TextBox txTimkiem;
        private System.Windows.Forms.Button btnTimkiem;
        private System.Windows.Forms.DataGridView dshpData;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnYeucaumolop;
        private System.Windows.Forms.Button btnDangkyhocct;
        private System.Windows.Forms.Button btnDangkyhoclai;
        private System.Windows.Forms.Button btnDangkyHPmoi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}