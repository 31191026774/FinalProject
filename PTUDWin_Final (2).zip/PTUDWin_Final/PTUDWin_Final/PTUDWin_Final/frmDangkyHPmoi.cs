﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTUDWin_Final
{
    public partial class frmDangkyHPmoi : Form
    {
        int HK = Global.HK;
        public frmDangkyHPmoi()
        {
            InitializeComponent();
            this.lbHoten.Text = Global.Name + " - " + Global.Id;

            String sql = "select malophp, tenmon, sotinchi, diengiai  " +
                "from chuongtrinh,chuongtrinhmonhoc, monhoc, LOPHOCPHAN, LOAIHP " +
                "where loaihp.maloaihp = LOPHOCPHAN.maloaihp and LOPHOCPHAN.mamon= MONHOC.mamon and" +
                " chuongtrinh.mact = chuongtrinhmonhoc.mact and chuongtrinhmonhoc.mamon = monhoc.mamon and chuongtrinh.tenct = N'" + Global.CTDT+ "'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            LoadDataMH(dt);
            LoadDataMHDDK();
        }
        private void LoadDataMH(DataTable dt)
        {

            dgvDSHPDK.DataSource = dt;
            dgvDSHPDK.Columns["malophp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSHPDK.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSHPDK.Columns["sotinchi"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSHPDK.Columns["diengiai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvDSHPDK.Columns["malophp"].HeaderText = "Mã học phần";
            dgvDSHPDK.Columns["tenmon"].HeaderText = "Tên học phần";
            dgvDSHPDK.Columns["sotinchi"].HeaderText = "Số tín chỉ";
            dgvDSHPDK.Columns["diengiai"].HeaderText = "Loại học phần";


        }
        private void LoadDataMHDDK()
        {
            string sql2 = "select LOPHOCPHAN.malophp, MONHOC.tenmon, Monhoc.sotinchi, loaihp.diengiai from monhoc, LOPHOCPHAN, LOAIHP, sinhvien, DSDANGKYTHANHCONG where loaihp.maloaihp = LOPHOCPHAN.maloaihp and LOPHOCPHAN.mamon= MONHOC.mamon  and sinhvien.masv = DSdangkythanhcong.Masv and DSdangkythanhcong.malophp = lophocphan.malophp and DSDangkythanhcong.masv = '" + Global.Id + "'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql2);

            dgvHPDKTC.DataSource = dt;
            dgvHPDKTC.Columns["malophp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvHPDKTC.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvHPDKTC.Columns["sotinchi"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvHPDKTC.Columns["diengiai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvHPDKTC.Columns["malophp"].HeaderText = "Mã học phần";
            dgvHPDKTC.Columns["tenmon"].HeaderText = "Tên học phần";
            dgvHPDKTC.Columns["sotinchi"].HeaderText = "Số tín chỉ";
            dgvHPDKTC.Columns["diengiai"].HeaderText = "Loại học phần";


        }

        private void rbtnNgoaikehoach_CheckedChanged(object sender, EventArgs e)
        {
            String sql = "select malophp, tenmon, sotinchi, diengiai  " +
                "from chuongtrinh,chuongtrinhmonhoc, monhoc, LOPHOCPHAN, LOAIHP " +
                "where loaihp.maloaihp = LOPHOCPHAN.maloaihp and LOPHOCPHAN.mamon= MONHOC.mamon and" +
                " chuongtrinh.mact = chuongtrinhmonhoc.mact and chuongtrinhmonhoc.mamon = monhoc.mamon and chuongtrinh.tenct = N'" + Global.CTDT + "'" +
                "and  lophocphan.sohk != '" + HK + "'";

            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            LoadDataMH(dt);
        }

        private void rbtnDungkehoach_CheckedChanged(object sender, EventArgs e)
        {
            String sql = "select malophp, tenmon, sotinchi, diengiai  " +
                "from chuongtrinh,chuongtrinhmonhoc, monhoc, LOPHOCPHAN, LOAIHP " +
                "where loaihp.maloaihp = LOPHOCPHAN.maloaihp and LOPHOCPHAN.mamon= MONHOC.mamon and" +
                " chuongtrinh.mact = chuongtrinhmonhoc.mact and chuongtrinhmonhoc.mamon = monhoc.mamon and chuongtrinh.tenct = N'" + Global.CTDT+ "'" +
                " and  lophocphan.sohk = '" + HK + "'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            LoadDataMH(dt);
        }

        private void dgvDSHPDK_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string mahp = dgvDSHPDK.Rows[dgvDSHPDK.CurrentCell.RowIndex].Cells[0].Value.ToString();
            Global.Mamon = DAO.DatabaseHelper.ExecuteQuerry("select lophocphan.mamon from monhoc, lophocphan where lophocphan.mamon = monhoc.mamon and malophp = '"+ mahp + "'").Rows[0]["mamon"].ToString();
            Global.MaHP = mahp;
            Global.SQL = "select tenmon, malophp, tengv from LOPHOCPHAN, GIAOVIEN, monhoc where lophocphan.magv = giaovien.magv and lophocphan.mamon = monhoc.mamon  and malophp = '" + mahp + "'";
            frmDangkylop frmDangkylop = new frmDangkylop();
            frmDangkylop.Show();
            this.Hide();
        }

        private void dgvHPDKTC_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var result = MessageBox.Show("Bạn có muốn hủy học phần này không?", "Hủy học phần",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                int rowIndex = dgvHPDKTC.CurrentCell.RowIndex;
                string mahp = dgvHPDKTC.Rows[rowIndex].Cells[0].Value.ToString();
                string huysql = "delete from DSdangkythanhcong where masv = '" + Global.Id + "' and malophp = '" + mahp + "'";
                string sqlupdate = "update LOPHOCPHAN  set dadangky = dadangky - 1 where  malophp = '" + mahp + "'";
                DAO.DatabaseHelper.ExecuteNonQuerry(huysql);
                DAO.DatabaseHelper.ExecuteNonQuerry(sqlupdate);
                LoadDataMHDDK();
            }
        }

        //public DataTable GetCauHoi(string MaCauHoi)
        //{
        //    DataTable dt = new DataTable();
        //    SqlConnection con = null;
        //    SqlDataAdapter da = new SqlDataAdapter("Select NOIDUNG from CAUHOI where MACAUHOI='" + MaCauHoi + "'", con);
        //    da.Fill(dt);

        //    return dt;

        //    lb.Text = obj.GetCauHoi("101").ToString();
        //}

    }
}
