﻿namespace PTUDWin_Final
{
    partial class frmDangkyhoclai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHoten = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvDSHPDKHL = new System.Windows.Forms.DataGridView();
            this.dgvDSDKHPTC = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSHPDKHL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSDKHPTC)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHoten
            // 
            this.lbHoten.AutoSize = true;
            this.lbHoten.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHoten.Location = new System.Drawing.Point(636, 40);
            this.lbHoten.Name = "lbHoten";
            this.lbHoten.Size = new System.Drawing.Size(40, 22);
            this.lbHoten.TabIndex = 33;
            this.lbHoten.Text = "Tên";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.panel2.Location = new System.Drawing.Point(1, 89);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1046, 34);
            this.panel2.TabIndex = 31;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PTUDWin_Final.Properties.Resources.hinh_avatar_trang;
            this.pictureBox2.Location = new System.Drawing.Point(910, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 69);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 36;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PTUDWin_Final.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 23);
            this.label1.TabIndex = 37;
            this.label1.Text = "Danh sách học phần đăng ký học lại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 453);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(342, 23);
            this.label2.TabIndex = 38;
            this.label2.Text = "Danh sách đăng ký học phần thành công";
            // 
            // dgvDSHPDKHL
            // 
            this.dgvDSHPDKHL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSHPDKHL.Location = new System.Drawing.Point(50, 188);
            this.dgvDSHPDKHL.MultiSelect = false;
            this.dgvDSHPDKHL.Name = "dgvDSHPDKHL";
            this.dgvDSHPDKHL.ReadOnly = true;
            this.dgvDSHPDKHL.RowHeadersWidth = 51;
            this.dgvDSHPDKHL.RowTemplate.Height = 24;
            this.dgvDSHPDKHL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSHPDKHL.Size = new System.Drawing.Size(935, 247);
            this.dgvDSHPDKHL.TabIndex = 39;
            this.dgvDSHPDKHL.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSHPDKHL_CellDoubleClick);
            // 
            // dgvDSDKHPTC
            // 
            this.dgvDSDKHPTC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSDKHPTC.Location = new System.Drawing.Point(50, 479);
            this.dgvDSDKHPTC.MultiSelect = false;
            this.dgvDSDKHPTC.Name = "dgvDSDKHPTC";
            this.dgvDSDKHPTC.ReadOnly = true;
            this.dgvDSDKHPTC.RowHeadersWidth = 51;
            this.dgvDSDKHPTC.RowTemplate.Height = 24;
            this.dgvDSDKHPTC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSDKHPTC.Size = new System.Drawing.Size(935, 230);
            this.dgvDSDKHPTC.TabIndex = 40;
            this.dgvDSDKHPTC.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSDKHPTC_CellDoubleClick);
            // 
            // frmDangkyhoclai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 739);
            this.Controls.Add(this.dgvDSDKHPTC);
            this.Controls.Add(this.dgvDSHPDKHL);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbHoten);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Name = "frmDangkyhoclai";
            this.Text = "frmDangkyhoclai";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSHPDKHL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSDKHPTC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbHoten;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDSHPDKHL;
        private System.Windows.Forms.DataGridView dgvDSDKHPTC;
    }
}