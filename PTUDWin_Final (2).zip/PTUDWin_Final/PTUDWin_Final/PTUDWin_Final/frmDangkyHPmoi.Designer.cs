﻿namespace PTUDWin_Final
{
    partial class frmDangkyHPmoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDSHPDK = new System.Windows.Forms.DataGridView();
            this.dgvHPDKTC = new System.Windows.Forms.DataGridView();
            this.lbDSHPDK = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rbtnDungkehoach = new System.Windows.Forms.RadioButton();
            this.rbtnNgoaikehoach = new System.Windows.Forms.RadioButton();
            this.lbHocki = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbHoten = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbNam = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSHPDK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHPDKTC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDSHPDK
            // 
            this.dgvDSHPDK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSHPDK.Location = new System.Drawing.Point(29, 170);
            this.dgvDSHPDK.MultiSelect = false;
            this.dgvDSHPDK.Name = "dgvDSHPDK";
            this.dgvDSHPDK.ReadOnly = true;
            this.dgvDSHPDK.RowHeadersWidth = 51;
            this.dgvDSHPDK.RowTemplate.Height = 24;
            this.dgvDSHPDK.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSHPDK.Size = new System.Drawing.Size(963, 312);
            this.dgvDSHPDK.TabIndex = 0;
            this.dgvDSHPDK.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSHPDK_CellDoubleClick);
            // 
            // dgvHPDKTC
            // 
            this.dgvHPDKTC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHPDKTC.Location = new System.Drawing.Point(29, 523);
            this.dgvHPDKTC.MultiSelect = false;
            this.dgvHPDKTC.Name = "dgvHPDKTC";
            this.dgvHPDKTC.ReadOnly = true;
            this.dgvHPDKTC.RowHeadersWidth = 51;
            this.dgvHPDKTC.RowTemplate.Height = 24;
            this.dgvHPDKTC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHPDKTC.Size = new System.Drawing.Size(964, 204);
            this.dgvHPDKTC.TabIndex = 1;
            this.dgvHPDKTC.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHPDKTC_CellDoubleClick);
            // 
            // lbDSHPDK
            // 
            this.lbDSHPDK.AutoSize = true;
            this.lbDSHPDK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDSHPDK.Location = new System.Drawing.Point(26, 139);
            this.lbDSHPDK.Name = "lbDSHPDK";
            this.lbDSHPDK.Size = new System.Drawing.Size(246, 23);
            this.lbDSHPDK.TabIndex = 2;
            this.lbDSHPDK.Text = "Danh sách học phần đăng ký";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 497);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(342, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "Danh sách học phần đăng ký thành công";
            // 
            // rbtnDungkehoach
            // 
            this.rbtnDungkehoach.AutoSize = true;
            this.rbtnDungkehoach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnDungkehoach.Location = new System.Drawing.Point(661, 139);
            this.rbtnDungkehoach.Name = "rbtnDungkehoach";
            this.rbtnDungkehoach.Size = new System.Drawing.Size(147, 26);
            this.rbtnDungkehoach.TabIndex = 4;
            this.rbtnDungkehoach.Text = "Đúng kế hoạch";
            this.rbtnDungkehoach.UseVisualStyleBackColor = true;
            this.rbtnDungkehoach.CheckedChanged += new System.EventHandler(this.rbtnDungkehoach_CheckedChanged);
            // 
            // rbtnNgoaikehoach
            // 
            this.rbtnNgoaikehoach.AutoSize = true;
            this.rbtnNgoaikehoach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnNgoaikehoach.Location = new System.Drawing.Point(839, 138);
            this.rbtnNgoaikehoach.Name = "rbtnNgoaikehoach";
            this.rbtnNgoaikehoach.Size = new System.Drawing.Size(153, 26);
            this.rbtnNgoaikehoach.TabIndex = 5;
            this.rbtnNgoaikehoach.Text = "Ngoài kế hoạch";
            this.rbtnNgoaikehoach.UseVisualStyleBackColor = true;
            this.rbtnNgoaikehoach.CheckedChanged += new System.EventHandler(this.rbtnNgoaikehoach_CheckedChanged);
            // 
            // lbHocki
            // 
            this.lbHocki.AutoSize = true;
            this.lbHocki.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHocki.Location = new System.Drawing.Point(489, 140);
            this.lbHocki.Name = "lbHocki";
            this.lbHocki.Size = new System.Drawing.Size(63, 22);
            this.lbHocki.TabIndex = 6;
            this.lbHocki.Text = "Học kì";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.panel2.Location = new System.Drawing.Point(0, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1046, 34);
            this.panel2.TabIndex = 7;
            // 
            // lbHoten
            // 
            this.lbHoten.AutoSize = true;
            this.lbHoten.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHoten.Location = new System.Drawing.Point(607, 37);
            this.lbHoten.Name = "lbHoten";
            this.lbHoten.Size = new System.Drawing.Size(40, 22);
            this.lbHoten.TabIndex = 9;
            this.lbHoten.Text = "Tên";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PTUDWin_Final.Properties.Resources.hinh_avatar_trang;
            this.pictureBox2.Location = new System.Drawing.Point(909, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 69);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PTUDWin_Final.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // lbNam
            // 
            this.lbNam.AutoSize = true;
            this.lbNam.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNam.Location = new System.Drawing.Point(580, 140);
            this.lbNam.Name = "lbNam";
            this.lbNam.Size = new System.Drawing.Size(47, 22);
            this.lbNam.TabIndex = 13;
            this.lbNam.Text = "Năm";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(558, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 22);
            this.label1.TabIndex = 14;
            this.label1.Text = "/";
            // 
            // frmDangkyHPmoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 739);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbNam);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbHoten);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbHocki);
            this.Controls.Add(this.rbtnNgoaikehoach);
            this.Controls.Add(this.rbtnDungkehoach);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbDSHPDK);
            this.Controls.Add(this.dgvHPDKTC);
            this.Controls.Add(this.dgvDSHPDK);
            this.Name = "frmDangkyHPmoi";
            this.Text = "Đăng ký học phần mới";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSHPDK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHPDKTC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDSHPDK;
        private System.Windows.Forms.DataGridView dgvHPDKTC;
        private System.Windows.Forms.Label lbDSHPDK;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbtnDungkehoach;
        private System.Windows.Forms.RadioButton rbtnNgoaikehoach;
        private System.Windows.Forms.Label lbHocki;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbHoten;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbNam;
        private System.Windows.Forms.Label label1;
    }
}