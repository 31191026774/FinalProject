﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PTUDWin_Final
{
    class Database
    {
        public static SqlConnection conn;
        public static SqlCommand cmd;
        public static SqlDataAdapter da;

        public static SqlConnection OpenDB()
        {
            conn = new SqlConnection(@"Data Source=DESKTOP-0ISHFT7\LAMPC;Initial Catalog = QLHP;User Id=sa;Password=123456;");
            return conn;
        }
        public static void OpenConnection()
        {
            string sql = @"Data Source=DESKTOP-0ISHFT7\LAMPC;Initial Catalog = QLHP;User Id=sa;Password=123456;";
            try
            {
                conn = new SqlConnection(sql);
                conn.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi kết nối: "+ex.Message);
            }
        }
        public static void Disconnection()
        {
            conn.Close();
            conn.Dispose();
            conn = null;
        }
        public static DataTable getDataTable(string sql)
        {
            cmd = new SqlCommand(sql, conn);
            da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable table = new DataTable();
            da.Fill(table);
            da.Dispose();
            cmd.Dispose();
            return table;
        }
        public static void Excute(string sql)
        {
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
        }
    }
}

