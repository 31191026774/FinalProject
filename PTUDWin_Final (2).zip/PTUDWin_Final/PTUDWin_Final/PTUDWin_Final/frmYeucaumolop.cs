﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTUDWin_Final
{
    public partial class frmYeucaumolop : Form
    {
        public frmYeucaumolop()
        {
            InitializeComponent();
            this.lbHoten.Text = Global.Name + " - " + Global.Id;
            string sql = "select monhoc.mamon, monhoc.tenmon, monhoc.sotinchi, loaihp.diengiai from monhoc, lophocphan, loaihp " +
                "where monhoc.mamon = lophocphan.mamon and lophocphan.maloaihp = loaihp.maloaihp and lophocphan.dadangky = lophocphan.soluongtoida";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            dataGridView1.DataSource = dt;

            dataGridView1.Columns["mamon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns["sotinchi"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns["diengiai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dataGridView1.Columns["mamon"].HeaderText = "Mã môn học";
            dataGridView1.Columns["tenmon"].HeaderText = "Tên học phần";
            dataGridView1.Columns["sotinchi"].HeaderText = "Số tín chỉ";
            dataGridView1.Columns["diengiai"].HeaderText = "Loại học phần";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Index = dataGridView1.CurrentCell.RowIndex;
            string mamon = dataGridView1.Rows[Index].Cells[0].Value.ToString();
            if (mamon != null)
            {
                string sql1 = "insert into yeucaubosung values ('" + mamon + "','" + Global.Id + "','Không có')";
                try
                {
                    DAO.DatabaseHelper.ExecuteNonQuerry(sql1);
                    MessageBox.Show("Yêu cầu mở lớp thành công!!!");
                }
                catch
                {
                    MessageBox.Show("Bạn đã yêu cầu mở lớp này rồi!!!");
                }
            }
            else
            {
                MessageBox.Show("Bạn chưa chọn lớp học phần");
            }    
        }
    }
}
