﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTUDWin_Final
{
    public partial class frmDangkyhoclai : Form
    {
        public frmDangkyhoclai()
        {
            InitializeComponent();
            this.lbHoten.Text = Global.Name + " - " + Global.Id;
            loadListDKHP();
            loadListDKHPTC();

            //số tín chỉ nằm trong học phần, lớp học phần và sinh viên môn học là hai bảng khác nhau chỗ nào??? vì sao lại có hai bảng này
            // bảng lớp học phần có trường năm đại diện cho cái gì
        }
        void loadListDKHP()
        {
            string sql = "select LOPHOCPHAN.malophp, MONHOC.tenmon, MONHOC.sotinchi, LOAIHP.maloaihp " +
                "from LOPHOCPHAN, MONHOC, LOAIHP, SINHVIEN, SINHVIENMONHOC " +
                "where SINHVIENMONHOC.Mamon = monhoc.mamon and LOPHOCPHAN.maloaihp = loaihp.maloaihp" +
                " and SINHVIEN.masv = SINHVIENMONHOC.masv and LOPHOCPHAN.mamon = MONHOC.mamon and SINHVIENMONHOC.diemchinhthuc <5" +
                "  and SINHVIENMONHOC.masv = '" + Global.Id + "' and LOPHOCPHA.sohk = '"+Global.HK +"'";
            // chọn số học kỳ = hk - 2x (số học kỳ >0);
            DataTable dataTable = DAO.DatabaseHelper.ExecuteQuerry(sql);
            dgvDSHPDKHL.DataSource = dataTable;
            dgvDSHPDKHL.Columns["malophp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSHPDKHL.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSHPDKHL.Columns["sotinchi"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSHPDKHL.Columns["maloaihp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvDSHPDKHL.Columns["malophp"].HeaderText = "Mã học phần";
            dgvDSHPDKHL.Columns["tenmon"].HeaderText = "Tên học phần";
            dgvDSHPDKHL.Columns["sotinchi"].HeaderText = "Số tín chỉ";
            dgvDSHPDKHL.Columns["maloaihp"].HeaderText = "Loại học phần";
        }
        void loadListDKHPTC()
        {
            string sql = "select DSDANGKYHOCLAI.malophp, MONHOC.Tenmon, MONHOC.sotinchi  from DSDANGKYHOCLAI, MONHOC, LOPHOCPHAN where DSDANGKYHOCLAI.malophp = LOPHOCPHAN.malophp and MONHOC.mamon = LOPHOCPHAN.mamon and masv = '" + Global.Id + "' and hkdangky = '" + Global.HK + "'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            dgvDSDKHPTC.DataSource = dt;
            dgvDSDKHPTC.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSDKHPTC.Columns["sotinchi"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSDKHPTC.Columns["malophp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvDSDKHPTC.Columns["malophp"].HeaderText = "Mã học phần";
            dgvDSDKHPTC.Columns["tenmon"].HeaderText = "Tên học phần";
            dgvDSDKHPTC.Columns["sotinchi"].HeaderText = "Số tín chỉ";
        }

        private void dgvDSHPDKHL_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn hủy học phần này không?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int status = 0;
                bool checkFlag = true;
                int malophpIndex = dgvDSHPDKHL.CurrentCell.RowIndex;
                string malophp = dgvDSHPDKHL.Rows[malophpIndex].Cells[0].Value.ToString();

                while (checkFlag == true)
                {
                    try
                    {


                        string sql4 = "select soluongtoida, dadangky from lophocphan where malophp = '" + malophp + "'";
                        DataTable dt4 = DAO.DatabaseHelper.ExecuteQuerry(sql4);
                        if ((int)dt4.Rows[0].ItemArray[0] <= (int)dt4.Rows[0].ItemArray[1])
                        {
                            status = 4;
                            checkFlag = false;
                            break;
                        }

                        //Kiểm tra có bị trùng lịch không
                        string sql3 = "select lichhoc from DSDANGKYTHANHCONG, LOPHOCPHAN where lophocphan.malophp = DSDANGKYTHANHCONG.malophp and masv = '" + Global.Id + "' and sokydangky = '" + Global.HK + "'";
                        string sql32 = "select lichhoc from LOPHOCPHAN where malophp = '" + malophp + "'";

                        string lichhoc = DAO.DatabaseHelper.ExecuteQuerry(sql32).Rows[0].ItemArray[0].ToString();
                        DataTable dt3 = DAO.DatabaseHelper.ExecuteQuerry(sql3);
                        foreach (DataRow dtRow in dt3.Rows)
                        {
                            if (dtRow[0].ToString() == lichhoc)
                            {
                                status = 3;
                                checkFlag = false;
                                break;
                            }
                        }
                        checkFlag = false;
                    }
                    catch
                    {
                        status=5;
                        checkFlag = false;
                        break;
                    }
                    


                }




                //switch conclusion box
                switch (status)
                {
                    case 0:
                        {
                            string insertSql = "insert into DSdangkythanhcong values ('" + Global.Id + "' , '" + malophp + "' , '" + Global.HK + "')";
                            string sqlupdate = "update LOPHOCPHAN  set dadangky = dadangky + 1 where  malophp = '" + malophp + "'";
                            DAO.DatabaseHelper.ExecuteNonQuerry(insertSql);
                            DAO.DatabaseHelper.ExecuteNonQuerry(sqlupdate);
                            string sqlhl = "insert into DSDANGKYHOCLAI values ('" + Global.Id + "','" + malophp + "','" + Global.HK + "')";
                            DAO.DatabaseHelper.ExecuteNonQuerry(sqlhl);
                            MessageBox.Show("Đăng ký thành công!!!");
                            loadListDKHPTC();
                            break;
                        }
                    case 4:
                        {
                            MessageBox.Show("Lớp học phần đã đủ số lượng sinh viên!!!");
                            break;
                        }
                    case 3:
                        {
                            MessageBox.Show("Trùng lịch!!!");
                            break;
                        }
                    default:
                        {
                            MessageBox.Show("Bạn chưa chọn lớp học phần!!!");
                            break;
                        }
                }
            }
        }

        private void dgvDSDKHPTC_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn hủy học phần này không?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int index = dgvDSDKHPTC.CurrentCell.RowIndex;
                string mahp = dgvDSDKHPTC.Rows[index].Cells[0].Value.ToString();
                if (mahp != "")
                {
                    string huysql = "delete from DSdangkythanhcong where masv = '" + Global.Id + "' and malophp = '" + mahp + "'";
                    string sqlupdate = "update LOPHOCPHAN  set dadangky = dadangky - 1 where  malophp = '" + mahp + "'";
                    string updateHL = " delete from DSDANGKYHOCLAI where masv = '" + Global.Id + "' and malophp = '" + mahp + "'";
                    DAO.DatabaseHelper.ExecuteNonQuerry(huysql);
                    DAO.DatabaseHelper.ExecuteNonQuerry(sqlupdate);
                    DAO.DatabaseHelper.ExecuteNonQuerry(updateHL);
                    MessageBox.Show("Hủy học phần thành công!!!");
                    loadListDKHPTC();
                }
                else
                {
                    MessageBox.Show("Bạn chưa chọn lớp học phần!!!");
                }    
            }
            
            
           
            
        }
    }
}
