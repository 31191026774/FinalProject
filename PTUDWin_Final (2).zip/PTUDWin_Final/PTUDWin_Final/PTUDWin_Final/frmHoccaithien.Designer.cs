﻿namespace PTUDWin_Final
{
    partial class frmHoccaithien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHoten = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvDSDKHCT = new System.Windows.Forms.DataGridView();
            this.dgvDSDKHCTTC = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSDKHCT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSDKHCTTC)).BeginInit();
            this.SuspendLayout();
            // 
            // lbHoten
            // 
            this.lbHoten.AutoSize = true;
            this.lbHoten.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHoten.Location = new System.Drawing.Point(622, 34);
            this.lbHoten.Name = "lbHoten";
            this.lbHoten.Size = new System.Drawing.Size(40, 22);
            this.lbHoten.TabIndex = 27;
            this.lbHoten.Text = "Tên";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.panel2.Location = new System.Drawing.Point(-2, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1046, 34);
            this.panel2.TabIndex = 25;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PTUDWin_Final.Properties.Resources.hinh_avatar_trang;
            this.pictureBox2.Location = new System.Drawing.Point(907, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 69);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PTUDWin_Final.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(-2, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 23);
            this.label1.TabIndex = 31;
            this.label1.Text = "Danh sách học phần đăng ký học cải thiện";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 408);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 16);
            this.label2.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(342, 23);
            this.label3.TabIndex = 33;
            this.label3.Text = "Danh sách đăng ký học phần thành công";
            // 
            // dgvDSDKHCT
            // 
            this.dgvDSDKHCT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSDKHCT.Location = new System.Drawing.Point(53, 179);
            this.dgvDSDKHCT.MultiSelect = false;
            this.dgvDSDKHCT.Name = "dgvDSDKHCT";
            this.dgvDSDKHCT.ReadOnly = true;
            this.dgvDSDKHCT.RowHeadersWidth = 51;
            this.dgvDSDKHCT.RowTemplate.Height = 24;
            this.dgvDSDKHCT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSDKHCT.Size = new System.Drawing.Size(920, 275);
            this.dgvDSDKHCT.TabIndex = 34;
            this.dgvDSDKHCT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSDKHCT_CellDoubleClick);
            // 
            // dgvDSDKHCTTC
            // 
            this.dgvDSDKHCTTC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSDKHCTTC.Location = new System.Drawing.Point(53, 500);
            this.dgvDSDKHCTTC.MultiSelect = false;
            this.dgvDSDKHCTTC.Name = "dgvDSDKHCTTC";
            this.dgvDSDKHCTTC.ReadOnly = true;
            this.dgvDSDKHCTTC.RowHeadersWidth = 51;
            this.dgvDSDKHCTTC.RowTemplate.Height = 24;
            this.dgvDSDKHCTTC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSDKHCTTC.Size = new System.Drawing.Size(920, 227);
            this.dgvDSDKHCTTC.TabIndex = 35;
            this.dgvDSDKHCTTC.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSDKHCTTC_CellDoubleClick);
            // 
            // frmHoccaithien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 739);
            this.Controls.Add(this.dgvDSDKHCTTC);
            this.Controls.Add(this.dgvDSDKHCT);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbHoten);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Name = "frmHoccaithien";
            this.Text = "frmHoccaithien";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSDKHCT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSDKHCTTC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbHoten;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvDSDKHCT;
        private System.Windows.Forms.DataGridView dgvDSDKHCTTC;
    }
}