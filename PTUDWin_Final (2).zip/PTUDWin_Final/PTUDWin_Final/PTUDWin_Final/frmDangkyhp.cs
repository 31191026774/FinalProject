﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTUDWin_Final
{
    public partial class frmDangkyhp : Form
    {
        Database ut = new Database();
        SqlConnection conn;

        public void ShowCombobox()
        {
            DataTable table = DAO.DatabaseHelper.ExecuteQuerry("select tenct, mact from CHUONGTRINH");
            ccbCtdt.DataSource = table;
            ccbCtdt.DisplayMember = "tenct";
        }
        public void ShowDL(DataTable dt)
        {
            dshpData.DataSource = dt;
            dshpData.Columns["malophp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dshpData.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dshpData.Columns["sotinchi"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dshpData.Columns["diengiai"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dshpData.Columns["malophp"].HeaderText = "Mã học phần";
            dshpData.Columns["tenmon"].HeaderText = "Tên học phần";
            dshpData.Columns["sotinchi"].HeaderText = "Số tín chỉ";
            dshpData.Columns["diengiai"].HeaderText = "Loại học phần";
            
        }
        public frmDangkyhp()
        {
            InitializeComponent();
            String sql = "select malophp, tenmon, sotinchi, diengiai  from chuongtrinh,chuongtrinhmonhoc, monhoc, LOPHOCPHAN, LOAIHP where loaihp.maloaihp = LOPHOCPHAN.maloaihp and LOPHOCPHAN.mamon= MONHOC.mamon and  chuongtrinh.mact = chuongtrinhmonhoc.mact and chuongtrinhmonhoc.mamon = monhoc.mamon";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            ShowCombobox();  
            ShowDL(dt);
        }
        private void ccbCtdt_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void btnDangkyHPmoi_Click(object sender, EventArgs e)
        {
            frmDangkyHPmoi frm = new frmDangkyHPmoi();
            frm.Show();
            this.Hide();
        }
        private void btnDangkyhoclai_Click(object sender, EventArgs e)
        {
            frmDangkyhoclai frm = new frmDangkyhoclai();
            frm.Show();
            this.Hide();
        }

        private void btnDangkyhocct_Click(object sender, EventArgs e)
        {
            frmHoccaithien frm = new frmHoccaithien();
            frm.Show();
            this.Hide();
        }

        private void btnYeucaumolop_Click(object sender, EventArgs e)
        {
            frmYeucaumolop frm = new frmYeucaumolop();
            frm.Show();
            this.Hide();
        }
        #region Timkiem
        public void LoadGridByKeyword()
        {
            conn = Database.OpenDB();
            conn.Open();
            string sql = "select malophp, tenmon, sotinchi, diengiai  from lophocphan, monhoc, loaihp where tenmon" + txTimkiem.Text + "%'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            dshpData.DataSource = dt;
            conn.Close();
        }
        private void btnTimkiem_Click(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            string a = ccbCtdt.Text;
            
            String sql = "select malophp, tenmon, sotinchi, diengiai from chuongtrinh,chuongtrinhmonhoc, monhoc, LOPHOCPHAN, LOAIHP " +
                "where loaihp.maloaihp = LOPHOCPHAN.maloaihp and LOPHOCPHAN.mamon= MONHOC.mamon" +
                " and  chuongtrinh.mact = chuongtrinhmonhoc.mact and chuongtrinhmonhoc.mamon = monhoc.mamon and chuongtrinh.tenct = N'" + a+"'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            ShowDL(dt);
            Global.CTDT = a;
        }
    }
}
