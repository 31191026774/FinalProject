﻿namespace PTUDWin_Final
{
    partial class frmDangnhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTendangnhap = new System.Windows.Forms.Label();
            this.lbMatkhau = new System.Windows.Forms.Label();
            this.txTendangnhap = new System.Windows.Forms.TextBox();
            this.txMatkhau = new System.Windows.Forms.TextBox();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnDangnhap = new System.Windows.Forms.Button();
            this.cbbLoaitaikhoan = new System.Windows.Forms.ComboBox();
            this.lbLoaitaikhoan = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbTendangnhap
            // 
            this.lbTendangnhap.AutoSize = true;
            this.lbTendangnhap.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTendangnhap.Location = new System.Drawing.Point(614, 216);
            this.lbTendangnhap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTendangnhap.Name = "lbTendangnhap";
            this.lbTendangnhap.Size = new System.Drawing.Size(124, 22);
            this.lbTendangnhap.TabIndex = 0;
            this.lbTendangnhap.Text = "Tên đăng nhập";
            // 
            // lbMatkhau
            // 
            this.lbMatkhau.AutoSize = true;
            this.lbMatkhau.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMatkhau.Location = new System.Drawing.Point(614, 294);
            this.lbMatkhau.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbMatkhau.Name = "lbMatkhau";
            this.lbMatkhau.Size = new System.Drawing.Size(82, 22);
            this.lbMatkhau.TabIndex = 1;
            this.lbMatkhau.Text = "Mật khẩu";
            // 
            // txTendangnhap
            // 
            this.txTendangnhap.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txTendangnhap.Location = new System.Drawing.Point(618, 250);
            this.txTendangnhap.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txTendangnhap.Name = "txTendangnhap";
            this.txTendangnhap.Size = new System.Drawing.Size(264, 30);
            this.txTendangnhap.TabIndex = 2;
            // 
            // txMatkhau
            // 
            this.txMatkhau.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txMatkhau.Location = new System.Drawing.Point(618, 332);
            this.txMatkhau.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txMatkhau.Name = "txMatkhau";
            this.txMatkhau.Size = new System.Drawing.Size(264, 30);
            this.txMatkhau.TabIndex = 3;
            this.txMatkhau.UseSystemPasswordChar = true;
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnThoat.Location = new System.Drawing.Point(640, 395);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(84, 39);
            this.btnThoat.TabIndex = 4;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnDangnhap
            // 
            this.btnDangnhap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.btnDangnhap.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangnhap.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDangnhap.Location = new System.Drawing.Point(749, 395);
            this.btnDangnhap.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnDangnhap.Name = "btnDangnhap";
            this.btnDangnhap.Size = new System.Drawing.Size(121, 39);
            this.btnDangnhap.TabIndex = 5;
            this.btnDangnhap.Text = "Đăng nhập";
            this.btnDangnhap.UseVisualStyleBackColor = false;
            this.btnDangnhap.Click += new System.EventHandler(this.btnDangnhap_Click);
            // 
            // cbbLoaitaikhoan
            // 
            this.cbbLoaitaikhoan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbLoaitaikhoan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbLoaitaikhoan.ForeColor = System.Drawing.Color.Black;
            this.cbbLoaitaikhoan.FormattingEnabled = true;
            this.cbbLoaitaikhoan.Items.AddRange(new object[] {
            "Sinh viên",
            "Giáo viên",
            "Quản lý"});
            this.cbbLoaitaikhoan.Location = new System.Drawing.Point(618, 166);
            this.cbbLoaitaikhoan.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cbbLoaitaikhoan.Name = "cbbLoaitaikhoan";
            this.cbbLoaitaikhoan.Size = new System.Drawing.Size(264, 30);
            this.cbbLoaitaikhoan.TabIndex = 6;
            this.cbbLoaitaikhoan.SelectedIndexChanged += new System.EventHandler(this.cbbLoaitaikhoan_SelectedIndexChanged);
            // 
            // lbLoaitaikhoan
            // 
            this.lbLoaitaikhoan.AutoSize = true;
            this.lbLoaitaikhoan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoaitaikhoan.ForeColor = System.Drawing.Color.Black;
            this.lbLoaitaikhoan.Location = new System.Drawing.Point(614, 129);
            this.lbLoaitaikhoan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbLoaitaikhoan.Name = "lbLoaitaikhoan";
            this.lbLoaitaikhoan.Size = new System.Drawing.Size(122, 22);
            this.lbLoaitaikhoan.TabIndex = 9;
            this.lbLoaitaikhoan.Text = "Loại tài khoản";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PTUDWin_Final.Properties.Resources.logo;
            this.pictureBox2.Location = new System.Drawing.Point(687, 12);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(139, 93);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PTUDWin_Final.Properties.Resources.bg_01;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(570, 503);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // frmDangnhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 503);
            this.Controls.Add(this.lbLoaitaikhoan);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cbbLoaitaikhoan);
            this.Controls.Add(this.btnDangnhap);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.txMatkhau);
            this.Controls.Add(this.txTendangnhap);
            this.Controls.Add(this.lbMatkhau);
            this.Controls.Add(this.lbTendangnhap);
            this.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "frmDangnhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTendangnhap;
        private System.Windows.Forms.Label lbMatkhau;
        private System.Windows.Forms.TextBox txTendangnhap;
        private System.Windows.Forms.TextBox txMatkhau;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnDangnhap;
        private System.Windows.Forms.ComboBox cbbLoaitaikhoan;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbLoaitaikhoan;
    }
}

