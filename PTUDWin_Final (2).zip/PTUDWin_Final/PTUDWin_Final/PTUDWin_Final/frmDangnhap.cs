﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PTUDWin_Final.DAO;


namespace PTUDWin_Final
{
    

    public partial class frmDangnhap : Form
    {
        public String TenSinhVien;
        public String MaSinhVien;
        public frmDangnhap()
        {
            InitializeComponent();

        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dg = MessageBox.Show("Bạn có muốn thoát ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dg == DialogResult.Yes)
                Application.Exit();
        }

        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            if (cbbLoaitaikhoan.SelectedIndex < 0)
            {
                MessageBox.Show("Vui lòng chọn tài khoản!","Lỗi đăng nhập");
                return;
            }

            if (string.IsNullOrEmpty(txTendangnhap.Text))
            {
                MessageBox.Show("Tên đăng nhập không được để trống!", "Lỗi đăng nhập");
                txTendangnhap.Select();
                return;
            }

            if (string.IsNullOrEmpty(txMatkhau.Text))
            {
                MessageBox.Show("Mật khẩu không được để trống!", "Lỗi đăng nhập");
                txMatkhau.Select();
                return;
            }
            String loaiTaiKhoan = cbbLoaitaikhoan.Text;
            string tk = txTendangnhap.Text;
            string mk = txMatkhau.Text;

            switch (loaiTaiKhoan)
            {
                case "Sinh viên":
                    {
                        string sql = "select * from SINHVIEN, LOPHOC where SINHVIEN.malophoc = LOPHOC.malophoc and masv='" + tk + "'and matkhau ='" + mk + "'";
                        DataTable data = DAO.DatabaseHelper.ExecuteQuerry(sql);
                        if (data != null && data.Rows.Count > 0)
                        {
                            DataRow dr = data.Rows[0];
                            Global.Id = dr["masv"].ToString();
                            Global.Name = dr["tensv"].ToString();
                            DateTime thisDay = DateTime.Today;
                            DateTime joinDay = (DateTime)dr["namvao"];
                            int HK = (thisDay.Year - joinDay.Year) * 2 + (int)((thisDay.Month <= 12 && thisDay.Month >= 8) ? 1 : 0)
                               + (int)((joinDay.Month <= 5 && joinDay.Month >= 1) ? 1 : 0);
                            // condition? a: b
                            // if (condition == true ) return a else return b
                            Global.HK = HK;
                            frmMain frm = new frmMain();
                            frm.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!!!");
                        }
                        break;
                    }
                case "Giáo viên":
                    {
                        MessageBox.Show("Chức năng hiện chưa có");
                        break;
                    }
                case "Quản lý":
                    {
                        MessageBox.Show("Chức năng hiện chưa có");
                        break;
                    }
            }
        }

        private void cbbLoaitaikhoan_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbbLoaitaikhoan.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
static class Global
{
    private static string TenSinhVien = "";
    private static string MaSinhVien = "";
    private static int HKHienTai = 1;
    private static string _CTDT = "Kinh tế";
    private static string _sql;
    private static string _mahp = "";
    private static string _mamon = "";
    
    public static string Mamon
    {
        get { return _mamon; }
        set { _mamon = value; }
    }    
    public static string Name
    {
        get { return TenSinhVien; }
        set { TenSinhVien = value; }
    }
    public static string Id
    {
        get { return MaSinhVien; }
        set { MaSinhVien = value; }
    }
    public static int HK
    {
        get { return HKHienTai; }
        set { HKHienTai = value; }
    }
    public static string CTDT
    {
        get { return _CTDT; }
        set { _CTDT = value; }
    }
    public static string SQL
    {
        get { return _sql; }
        set { _sql = value; }
    }
    public static string MaHP
    {
        get { return _mahp; }
        set { _mahp = value; }
    }
}