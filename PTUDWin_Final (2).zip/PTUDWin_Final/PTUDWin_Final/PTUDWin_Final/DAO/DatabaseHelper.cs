﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PTUDWin_Final.DAO
{
    internal class DatabaseHelper
    {
        public static SqlConnection Con;
        public static string constr = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Winn;Integrated Security=True;";

        public static void Connect()
        {
            Con = new SqlConnection();
            Con.ConnectionString = constr;
            Con.Open();

            if (Con.State != ConnectionState.Open)
                MessageBox.Show("Kết nối cơ sở dữ liệu thất bại");
        }
        public static void Disconnect()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();   	//Đóng kết nối
                Con.Dispose(); 	//Giải phóng tài nguyên
                Con = null;
            }
        }
        public static DataTable ExecuteQuerry(string Querry)
        {
            DataTable data = new DataTable();
            Con = new SqlConnection();
            Con.ConnectionString = constr;
            Con.Open();
            SqlCommand command = new SqlCommand(Querry, Con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(data);
            Con.Close();
            return data;
        }
        public static int ExecuteNonQuerry(string Querry)
        {
            int data = 0;
            Con = new SqlConnection();
            Con.ConnectionString = constr;
            Con.Open();
            SqlCommand command = new SqlCommand(Querry, Con);
            data = command.ExecuteNonQuery();
            command.Dispose();
            Con.Close();
            return data;
        }
    }

}
