﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTUDWin_Final
{
    public partial class frmDangkylop : Form
    {
        public frmDangkylop()
        {
            InitializeComponent();
            this.lbHoten.Text = Global.Name + " - " + Global.Id;
            string sql = "select LOPHOCPHAN.mamon, tenmon, malophp, tengv, soluongtoida, dadangky from LOPHOCPHAN, GIAOVIEN, monhoc " +
                "where lophocphan.magv = giaovien.magv and lophocphan.mamon = monhoc.mamon  and monhoc.mamon = '" + Global.Mamon + "'";
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry(sql);
            dgvDSCLHP.DataSource = dt;
            dgvDSCLHP.Columns["mamon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSCLHP.Columns["tenmon"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSCLHP.Columns["malophp"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;  
            dgvDSCLHP.Columns["tengv"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSCLHP.Columns["soluongtoida"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvDSCLHP.Columns["dadangky"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvDSCLHP.Columns["mamon"].HeaderText = "Mã môn";
            dgvDSCLHP.Columns["tenmon"].HeaderText = "Tên học phần";
            dgvDSCLHP.Columns["malophp"].HeaderText = "Mã học phần";
            dgvDSCLHP.Columns["tengv"].HeaderText = "Tên giáo viên";
            dgvDSCLHP.Columns["soluongtoida"].HeaderText = "Số lượng tối đa";
            dgvDSCLHP.Columns["dadangky"].HeaderText = "Đã đăng ký";

            lbTenHP.Text = dgvDSCLHP.Rows[0].Cells[0].Value.ToString(); 
        }

        private void btnQuaylaiDSM_Click(object sender, EventArgs e)
        {
            frmDangkyHPmoi frm = new frmDangkyHPmoi();
            frm.Show();
            this.Hide();
        }

        private void btnDangky_Click(object sender, EventArgs e)
        {
            int status = 0;
            bool checkFlag = true;
            string Mamon = dgvDSCLHP.Rows[0].Cells[0].Value.ToString();
            DataTable dt = DAO.DatabaseHelper.ExecuteQuerry("select dsmontienquyet, dsmontruoc from monhoc, lophocphan " +
                "where monhoc.mamon = lophocphan.mamon and lophocphan.mamon = monhoc.mamon and monhoc.mamon = '" + Mamon + "'");
            while (checkFlag == true)
            {
                //Kiểm tra đã qua môn tiên quyết chưa và đã học môn học trước chưa
                if (dt != null && dt.Rows.Count !=0)
                {
                    //Kiểm tra đã qua môn tiên quyết chưa
                    if (dt.Rows[0].ItemArray[0].ToString() != "")
                    {
                        DataTable dt1 = DAO.DatabaseHelper.ExecuteQuerry("select diemchinhthuc from SINHVIENMONHOC, monhoc where sinhvienmonhoc.mamon = monhoc.mamon and sinhvienmonhoc.mamon = (select dsmontienquyet from monhoc, lophocphan where monhoc.mamon = lophocphan.mamon and lophocphan.mamon = monhoc.mamon and monhoc.mamon = '" + Mamon + "') and masv = '" + Global.Id + "'");

                        try
                        {
                            Double Score = (Double)dt1.Rows[0].ItemArray[0];
                            if (Score < 5)
                            {
                                checkFlag = false;
                                status = 1;
                                break;
                            }
                        }
                        catch
                        {                            
                            checkFlag = false;
                            status = 1;
                            break;
                        }
                    }
                    // kiểm tra đã học môn học trước chưa
                    if (dt.Rows[0].ItemArray[1].ToString() != "")
                    {
                        DataTable dt2 = DAO.DatabaseHelper.ExecuteQuerry("select diemchinhthuc from SINHVIENMONHOC, monhoc where sinhvienmonhoc.mamon = monhoc.mamon and sinhvienmonhoc.mamon = (select dsmontienquyet from monhoc, lophocphan where monhoc.mamon = lophocphan.mamon and lophocphan.mamon = monhoc.mamon and monhoc.mamon = '" + Mamon + "') and masv = '" + Global.Id + "'");
                        try
                        {
                            Double Score = (Double)dt2.Rows[0].ItemArray[0];
                            if (Score == 0)
                            {
                                checkFlag = false;
                                status = 2;
                                break;
                            }
                        }
                        catch
                        {
                            checkFlag = false;
                            status = 2;
                            break;
                        }
                    }
                    

                    string sql4 = "select soluongtoida, dadangky from lophocphan where malophp = '" + Global.MaHP + "'";
                    DataTable dt4 = DAO.DatabaseHelper.ExecuteQuerry(sql4);
                    if ((int) dt4.Rows[0].ItemArray[0] <= (int) dt4.Rows[0].ItemArray[1])
                    {
                        status = 4;
                        checkFlag = false;
                        break;
                    }
                    //Kiểm tra có bị trùng lịch không
                    string sql3 = "select lichhoc from DSDANGKYTHANHCONG, LOPHOCPHAN where lophocphan.malophp = DSDANGKYTHANHCONG.malophp and masv = '" + Global.Id + "'";
                    string sql32 = "select lichhoc from LOPHOCPHAN where malophp = '" + Global.MaHP + "'";
                    string lichhoc = DAO.DatabaseHelper.ExecuteQuerry(sql32).Rows[0].ItemArray[0].ToString();
                    DataTable dt3 = DAO.DatabaseHelper.ExecuteQuerry(sql3);
                    foreach (DataRow dtRow in dt3.Rows)
                    {
                        if (dtRow[0].ToString() == lichhoc)
                        {
                            status = 3;
                            checkFlag = false;
                            break;
                        }
                    }
                    checkFlag = false;   
                }
                   

                   

                    //switch conclusion box
            }
            switch(status)
            {
                case 0:
                    {
                        int rowIndex = dgvDSCLHP.CurrentCell.RowIndex;
                        string mahp = dgvDSCLHP.Rows[rowIndex].Cells[2].Value.ToString();
                        string insertSql = "insert into DSdangkythanhcong values ('"+Global.Id+"' , '"+mahp+"' , '"+Global.HK+"')";
                        string sqlupdate = "update LOPHOCPHAN  set dadangky = dadangky + 1 where  malophp = '" + mahp + "'";
                        DAO.DatabaseHelper.ExecuteNonQuerry(insertSql);
                        DAO.DatabaseHelper.ExecuteNonQuerry(sqlupdate);
                        MessageBox.Show("Đăng ký thành công!!!");
                        break;
                    }
                case 1:
                    {
                        MessageBox.Show("Bạn bị giới hạn bởi môn học tiên quyết!!!");
                        break;
                    }
                case 2:
                    {
                        MessageBox.Show("Bạn bị giới hạn bởi môn học trước!!!");
                        break;
                    }
                case 4:
                    {
                        MessageBox.Show("Lớp học phần đã đủ số lượng sinh viên!!!");
                        break;
                    }
                case 3:
                    {
                        MessageBox.Show("Trùng lịch!!!");
                        break;
                    }
            }

        }
    }
}
